// Your JavaScript code here
const customQAs = [
  {
    question: "What is your name?",
    answer: "I am ChatGPT, your assistant."
  },
  {
    question: "What can you do?",
    answer: "I can help with a wide range of tasks, from answering questions to providing recommendations."
  }
];

// API call and logic omitted for brevity
